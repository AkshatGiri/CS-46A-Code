
/**
 * Console inputs
 *
 * @author Akshat Giri
 */
import java.util.Scanner;
public class IfPractice
{
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your first and last name: ");
        String name = scanner.nextLine();
        System.out.println("Hello, " + name + "!");
        
       
    }
}
