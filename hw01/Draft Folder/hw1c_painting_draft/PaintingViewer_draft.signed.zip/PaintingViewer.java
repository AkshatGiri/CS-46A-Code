//SOLUTION
/**
 * Enlarges an image of a painting
 * 
 * @author Kathleen O'Brien
 */
public class PaintingViewer
{
    public static void main(String[] args)
    {
//HIDE
        Picture something = new Picture("starry_night.png");
        something.draw();
//SHOW
    }
}