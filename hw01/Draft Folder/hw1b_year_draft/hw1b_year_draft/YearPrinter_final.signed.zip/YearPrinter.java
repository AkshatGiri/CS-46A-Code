public class YearPrinter
{
    public static void main(String[] args)
    {
        String M = "\u216F";
        String X = "\u2169";
        String V = "\u2166";
        System.out.println("|*YEAR**|");
        System.out.println("|*2017**|");
        System.out.println("|*"+ M+M+X+V +"*|");
        System.out.println("|*******|");
    }
}
