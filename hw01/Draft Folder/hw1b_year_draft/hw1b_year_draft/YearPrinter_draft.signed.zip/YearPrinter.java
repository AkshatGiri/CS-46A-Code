public class YearPrinter
{
    public static void main(String[] args)
    {
        System.out.println("|*YEAR**|");
        System.out.println("|*2017**|");
    }
}
